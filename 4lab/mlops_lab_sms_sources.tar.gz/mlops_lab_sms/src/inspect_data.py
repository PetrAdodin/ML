
import csv
import pandas as pd

df = pd.read_csv(
    "data/raw/SMSSpamCollection",
    sep="\t",
    header=None,
    names=["label", "text"],
    encoding="latin-1",
    quoting=csv.QUOTE_NONE,
    dtype=str,
    keep_default_na=False,
)

print("Размер датасета:", df.shape)
print("\nРаспределение классов:")
print(df["label"].value_counts())

print("\nПустые сообщения:",
      (df["text"].str.strip() == "").sum())

print("Полные дубликаты:",
      df.duplicated().sum())

print("Повторяющиеся тексты:",
      df.duplicated(subset=["text"]).sum())

conflicts = df.groupby("text")["label"].nunique()
print("Сообщения с противоречивыми метками:",
      (conflicts > 1).sum())

print("\nПервые 5 записей:")
print(df.head().to_string(index=False, max_colwidth=60))
