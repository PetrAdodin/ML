
import csv
import hashlib
import json
from pathlib import Path

import mlflow.sklearn
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

ROOT = Path(__file__).resolve().parent.parent

raw_path = ROOT / "data/raw/SMSSpamCollection"
split_path = ROOT / "data/splits.json"
model_path = ROOT / "exported_model"

splits = json.loads(split_path.read_text())
metadata = json.loads(
    (model_path / "metadata.json").read_text()
)

assert hashlib.sha256(raw_path.read_bytes()).hexdigest() == (
    splits["source_sha256"]
)

df = pd.read_csv(
    raw_path,
    sep="\t",
    header=None,
    names=["label", "text"],
    encoding="latin-1",
    quoting=csv.QUOTE_NONE,
    dtype=str,
    keep_default_na=False,
)

df = df.drop_duplicates(subset=["text"]).reset_index(drop=True)

assert len(df) == splits["clean_rows"]

test = df.loc[splits["test_indices"]]

X_test = test["text"].to_numpy(dtype=str)
y_test = test["label"].to_numpy(dtype=str)

model = mlflow.sklearn.load_model(str(model_path))
predictions = model.predict(X_test)

tn, fp, fn, tp = confusion_matrix(
    y_test,
    predictions,
    labels=["ham", "spam"],
).ravel()

results = {
    "model_name": metadata["model_name"],
    "model_version": metadata["model_version"],
    "run_id": metadata["run_id"],
    "test_samples": len(test),
    "test_accuracy": float(
        accuracy_score(y_test, predictions)
    ),
    "test_precision_spam": float(
        precision_score(
            y_test, predictions, pos_label="spam",
            zero_division=0
        )
    ),
    "test_recall_spam": float(
        recall_score(
            y_test, predictions, pos_label="spam",
            zero_division=0
        )
    ),
    "test_f1_spam": float(
        f1_score(
            y_test, predictions, pos_label="spam",
            zero_division=0
        )
    ),
    "true_negative": int(tn),
    "false_positive": int(fp),
    "false_negative": int(fn),
    "true_positive": int(tp),
}

output = ROOT / "test_metrics.json"
output.write_text(
    json.dumps(results, indent=2),
    encoding="utf-8",
)

print("FINAL TEST EVALUATION")
print(json.dumps(results, indent=2))
print("\nResults saved to:", output)
