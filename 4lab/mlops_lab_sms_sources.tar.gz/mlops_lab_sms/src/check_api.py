
import json
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

request_body = (
    ROOT / "sample_request.json"
).read_bytes()

expected = json.loads(
    (ROOT / "expected_predictions.json").read_text(
        encoding="utf-8"
    )
)

metadata = json.loads(
    (ROOT / "exported_model/metadata.json").read_text(
        encoding="utf-8"
    )
)

request = urllib.request.Request(
    "http://127.0.0.1:8000/predict",
    data=request_body,
    headers={"Content-Type": "application/json"},
    method="POST",
)

with urllib.request.urlopen(request, timeout=30) as response:
    status = response.status
    result = json.load(response)

assert status == 200, f"Unexpected HTTP status: {status}"

assert result["predictions"] == expected, (
    f"Predictions mismatch: {result['predictions']} != {expected}"
)

assert result["model_version"] == metadata["model_version"], (
    "Model version mismatch"
)

print("PASS: API predictions match exported model")
print("HTTP status:", status)
print("Model version:", result["model_version"])
print("Expected:", expected)
print("Actual:", result["predictions"])
