
import csv
import hashlib
import json
import os
import shutil
from pathlib import Path

import mlflow
import mlflow.sklearn
import numpy as np
import pandas as pd

from mlflow import MlflowClient
from mlflow.models import infer_signature

ROOT = Path(__file__).resolve().parent.parent

mlflow.set_tracking_uri(
    os.getenv("MLFLOW_TRACKING_URI", "http://127.0.0.1:5000")
)

client = MlflowClient()

version = client.get_model_version_by_alias(
    "sms-spam-classifier", "champion"
)

model_uri = f"models:/sms-spam-classifier/{version.version}"
model = mlflow.sklearn.load_model(model_uri)

raw_path = ROOT / "data/raw/SMSSpamCollection"
split_path = ROOT / "data/splits.json"

splits = json.loads(split_path.read_text())

source_hash = hashlib.sha256(raw_path.read_bytes()).hexdigest()
assert source_hash == splits["source_sha256"]

df = pd.read_csv(
    raw_path,
    sep="\t",
    header=None,
    names=["label", "text"],
    encoding="latin-1",
    quoting=csv.QUOTE_NONE,
    dtype=str,
    keep_default_na=False,
)

df = df.drop_duplicates(subset=["text"]).reset_index(drop=True)

assert len(df) == splits["clean_rows"]

test_ids = splits["test_indices"]
sample_texts = df.loc[test_ids, "text"].head(3).tolist()

X_sample = np.array(sample_texts, dtype=str)
expected = model.predict(X_sample).tolist()

signature = infer_signature(X_sample, expected)

out = ROOT / "exported_model"

if out.exists():
    shutil.rmtree(out)

mlflow.sklearn.save_model(
    model,
    path=str(out),
    signature=signature,
    input_example=X_sample,
    pip_requirements=(
        ROOT / "requirements.txt"
    ).read_text().splitlines(),
)

metadata = {
    "model_name": "sms-spam-classifier",
    "model_version": str(version.version),
    "run_id": version.run_id,
    "model_uri": model_uri,
    "classes": model.classes_.tolist(),
    "input_field": "texts",
    "dataset_sha256": source_hash,
    "split_sha256": hashlib.sha256(
        split_path.read_bytes()
    ).hexdigest(),
}

(out / "metadata.json").write_text(
    json.dumps(metadata, indent=2),
    encoding="utf-8",
)

(ROOT / "sample_request.json").write_text(
    json.dumps({"texts": sample_texts}, indent=2),
    encoding="utf-8",
)

(ROOT / "expected_predictions.json").write_text(
    json.dumps(expected, indent=2),
    encoding="utf-8",
)

print("MODEL EXPORTED SUCCESSFULLY")
print(json.dumps(metadata, indent=2))
print("Expected predictions:", expected)
