
import csv
import hashlib
import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

root = Path(__file__).resolve().parent.parent
raw = root / "data/raw/SMSSpamCollection"

df = pd.read_csv(
    raw,
    sep="\t",
    header=None,
    names=["label", "text"],
    encoding="latin-1",
    quoting=csv.QUOTE_NONE,
    dtype=str,
    keep_default_na=False,
)

assert df["label"].isin(["ham", "spam"]).all()
assert df["text"].str.strip().ne("").all()

original_count = len(df)
df = df.drop_duplicates(subset=["text"]).reset_index(drop=True)

indices = df.index.to_numpy()

dev, test = train_test_split(
    indices,
    test_size=0.2,
    random_state=42,
    stratify=df["label"],
)

train, val = train_test_split(
    dev,
    test_size=0.25,
    random_state=42,
    stratify=df.loc[dev, "label"],
)

splits = {
    "source_sha256": hashlib.sha256(raw.read_bytes()).hexdigest(),
    "original_rows": original_count,
    "clean_rows": len(df),
    "random_state": 42,
    "train_indices": train.tolist(),
    "validation_indices": val.tolist(),
    "test_indices": test.tolist(),
}

output = root / "data/splits.json"
output.write_text(json.dumps(splits, indent=2))

print("Исходных сообщений:", original_count)
print("Удалено дубликатов:", original_count - len(df))
print("После очистки:", len(df))

for name, ids in [("Train", train), ("Validation", val), ("Test", test)]:
    subset = df.loc[ids]
    print(f"{name}: {len(subset)}")
    print(subset["label"].value_counts().to_dict())

print("Разбиение сохранено:", output)
