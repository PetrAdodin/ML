
import json
import logging
import time
from pathlib import Path

import mlflow.sklearn

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

MODEL_DIR = Path("/app/exported_model")

model = mlflow.sklearn.load_model(str(MODEL_DIR))

metadata_info = json.loads(
    (MODEL_DIR / "metadata.json").read_text(
        encoding="utf-8"
    )
)

app = FastAPI(
    title="SMS Spam Classification API",
    description="MLOps Lab 4, Variant 2",
    version="1.0",
)

logger = logging.getLogger("uvicorn.error")


class PredictRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    texts: list[str] = Field(
        min_length=1,
        max_length=100,
    )


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model_version": metadata_info["model_version"],
    }


@app.get("/metadata")
def get_metadata():
    return metadata_info


@app.post("/predict")
def predict(body: PredictRequest):
    start = time.perf_counter()

    if any(not text.strip() for text in body.texts):
        raise HTTPException(
            status_code=422,
            detail="SMS text must not be empty",
        )

    if any(len(text) > 5000 for text in body.texts):
        raise HTTPException(
            status_code=422,
            detail="SMS text exceeds 5000 characters",
        )

    predictions = model.predict(body.texts).tolist()

    elapsed = (time.perf_counter() - start) * 1000

    logger.info(
        "prediction model_version=%s rows=%s latency_ms=%.3f",
        metadata_info["model_version"],
        len(body.texts),
        elapsed,
    )

    return {
        "predictions": predictions,
        "model_version": metadata_info["model_version"],
        "latency_ms": round(elapsed, 3),
    }
