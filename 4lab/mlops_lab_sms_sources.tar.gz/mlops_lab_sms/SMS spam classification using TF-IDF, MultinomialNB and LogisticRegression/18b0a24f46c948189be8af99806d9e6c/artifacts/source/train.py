
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path

import mlflow
import mlflow.sklearn
import numpy as np
import pandas as pd

from mlflow.models import infer_signature
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
)

ROOT = Path(__file__).resolve().parent.parent

parser = argparse.ArgumentParser()
parser.add_argument("--algorithm", choices=["nb", "lr"], required=True)
parser.add_argument("--alpha", type=float, default=1.0)
parser.add_argument("--c", type=float, default=1.0)
parser.add_argument("--register", action="store_true")
args = parser.parse_args()

mlflow.set_tracking_uri(
    os.getenv("MLFLOW_TRACKING_URI", "http://127.0.0.1:5000")
)
mlflow.set_experiment("lab4-sms-spam")

raw_path = ROOT / "data/raw/SMSSpamCollection"
split_path = ROOT / "data/splits.json"

df = pd.read_csv(
    raw_path,
    sep="\t",
    header=None,
    names=["label", "text"],
    encoding="latin-1",
    quoting=csv.QUOTE_NONE,
    dtype=str,
    keep_default_na=False,
)

df = df.drop_duplicates(subset=["text"]).reset_index(drop=True)
splits = json.loads(split_path.read_text())

raw_hash = hashlib.sha256(raw_path.read_bytes()).hexdigest()
assert raw_hash == splits["source_sha256"]
assert len(df) == splits["clean_rows"]

train = df.loc[splits["train_indices"]]
val = df.loc[splits["validation_indices"]]

X_train = train["text"].to_numpy(dtype=str)
y_train = train["label"].to_numpy(dtype=str)
X_val = val["text"].to_numpy(dtype=str)
y_val = val["label"].to_numpy(dtype=str)

if args.algorithm == "nb":
    classifier = MultinomialNB(alpha=args.alpha)
    run_name = f"NB-alpha-{args.alpha}"
    params = {"alpha": args.alpha}
else:
    classifier = LogisticRegression(
        C=args.c,
        max_iter=2000,
        random_state=42,
    )
    run_name = f"LR-C-{args.c}"
    params = {"C": args.c}

model = make_pipeline(
    TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        min_df=2,
    ),
    classifier,
)

with mlflow.start_run(run_name=run_name) as run:
    mlflow.log_params({
        "algorithm": args.algorithm,
        "seed": 42,
        "ngram_range": "(1, 2)",
        "min_df": 2,
        "train_rows": len(train),
        "validation_rows": len(val),
        "test_rows": len(splits["test_indices"]),
        **params,
    })

    mlflow.set_tags({
        "variant": "2",
        "dataset": "UCI SMS Spam Collection",
        "dataset_sha256": raw_hash,
        "split_sha256": hashlib.sha256(
            split_path.read_bytes()
        ).hexdigest(),
        "selection_metric": "val_f1_spam",
        "positive_class": "spam",
    })

    model.fit(X_train, y_train)
    predictions = model.predict(X_val)

    metrics = {
        "val_accuracy": accuracy_score(y_val, predictions),
        "val_precision_spam": precision_score(
            y_val, predictions, pos_label="spam", zero_division=0
        ),
        "val_recall_spam": recall_score(
            y_val, predictions, pos_label="spam", zero_division=0
        ),
        "val_f1_spam": f1_score(
            y_val, predictions, pos_label="spam", zero_division=0
        ),
    }

    mlflow.log_metrics(metrics)

    mlflow.log_artifact(str(ROOT / "src/train.py"), "source")
    mlflow.log_artifact(str(ROOT / "requirements.txt"), "source")
    mlflow.log_artifact(str(split_path), "source")

    example = X_train[:3]
    signature = infer_signature(example, model.predict(example))

    info = mlflow.sklearn.log_model(
        model,
        name="model",
        signature=signature,
        input_example=example,
        pip_requirements=(
            ROOT / "requirements.txt"
        ).read_text().splitlines(),
    )

    print("\nRUN_ID:", run.info.run_id)
    print("MODEL_URI:", info.model_uri)
    print("METRICS:", json.dumps(metrics, indent=2))

    if args.register:
        mv = mlflow.register_model(
            info.model_uri,
            "sms-spam-classifier",
        )
        print("REGISTERED_VERSION:", mv.version)
