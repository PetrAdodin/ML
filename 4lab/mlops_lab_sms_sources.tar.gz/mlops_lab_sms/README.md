
# Лабораторная работа №4. MLOps

## Вариант 2. Сервис фильтрации SMS-спама

Цель: освоить MLflow, версионирование моделей,
контейнеризацию REST API, обновление и откат.

## 1. Датасет

Источник: UCI SMS Spam Collection
https://archive.ics.uci.edu/dataset/228/sms+spam+collection

Исходных сообщений: 5574.
После удаления 403 дубликатов: 5171.

Признак: text — текст SMS.
Целевая переменная: label (ham или spam).

Разбиение:
- Train: 3102
- Validation: 1034
- Test: 1035

random_state = 42.
Индексы разбиения сохранены в data/splits.json.
Исходный датасет хранится в data/raw/.

## 2. Окружение

- Ubuntu 26.04.1 LTS
- Python 3.12.16
- MLflow 3.5.0
- scikit-learn 1.7.2
- FastAPI 0.119.0
- Docker Engine 29.9.3
- Docker Compose 5.7.0

Основные зависимости: requirements.txt.
Полный снимок: requirements.lock.txt.

## 3. Обучение

Используются TF-IDF и два классификатора:
MultinomialNB и LogisticRegression.

TF-IDF обучается только на Train и сохраняется
в одном Pipeline с моделью.

Основная метрика: F1 для класса spam.
Дополнительные: Accuracy, Precision, Recall.

Запуск MLflow:

    .venv/bin/mlflow server \
      --backend-store-uri sqlite:///mlflow-data/mlflow.db \
      --artifacts-destination ./mlflow-data/artifacts \
      --serve-artifacts \
      --host 127.0.0.1 --port 5000

Шесть экспериментов:

    .venv/bin/python src/train.py --algorithm nb --alpha 0.1
    .venv/bin/python src/train.py --algorithm nb --alpha 1.0
    .venv/bin/python src/train.py --algorithm nb --alpha 0.01
    .venv/bin/python src/train.py --algorithm lr --c 0.1
    .venv/bin/python src/train.py --algorithm lr --c 1.0
    .venv/bin/python src/train.py --algorithm lr --c 10.0

## 4. Результаты

Лучшая модель по Validation:
MultinomialNB, alpha=0.1.

Validation F1 (spam): 0.9306.
Test F1 (spam): 0.9360.
Test Accuracy: 0.9845.

Registered Model: sms-spam-classifier.

Version 1: MultinomialNB, alpha=0.1.
Version 2: LogisticRegression, C=10.

Итоговый alias champion: Version 1.

## 5. Экспорт и оценка

    .venv/bin/python src/export_model.py
    .venv/bin/python src/evaluate.py

Экспорт содержит TF-IDF, классификатор,
сигнатуру входа и метаданные модели.

## 6. REST API

GET /health — состояние сервиса.
GET /metadata — метаданные модели.
POST /predict — классификация SMS.

Пример запроса:

    {"texts": ["Hello!", "Win a free prize now!"]}

Результат содержит:
predictions, model_version, latency_ms.

API проверяет корректность входных данных.

## 7. Docker

Сборка:

    sudo docker build -t sms-spam-api:v1 .

Запуск:

    sudo docker run -d --name sms-spam-api \
      -p 127.0.0.1:8000:8000 sms-spam-api:v1

Проверка:

    curl http://127.0.0.1:8000/health
    .venv/bin/python src/check_api.py

Swagger UI:
http://127.0.0.1:8000/docs

## 8. Обновление и откат

Для обновления используется Version 2
и Docker-образ sms-spam-api:v2.

Для отката используется сохранённый
Docker-образ sms-spam-api:v1.

Повторное обучение не требуется.
После отката alias champion возвращается
на Version 1.

## 9. Docker Compose

Запуск:

    sudo docker compose up -d --build

Проверка:

    sudo docker compose ps
    sudo docker compose logs --tail 30

Остановка:

    sudo docker compose down

Для Compose используется отдельный
тег sms-spam-api:compose-demo.

## 10. Воспроизводимость

Исходный датасет сохраняется без изменений.
Его SHA-256 и индексы разбиения зафиксированы.

В data/splits.json хранится разбиение.
В requirements.lock.txt — версии зависимостей.
В MLflow — параметры, метрики и артефакты.

Для восстановления экспериментов необходимы
исходные файлы, зависимости и работающий MLflow.
